using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace IncrementBuildNr
{
   class Program
   {
      static String incrementVersion( String psLine )
      {
         String lsVersion = psLine.Substring( psLine.IndexOf( "\"" ) + 1 );
         lsVersion = lsVersion.Substring( 0, lsVersion.IndexOf( "\"" ) );

         String[] lasVersions = lsVersion.Split( '.' );

         if(lasVersions == null || lasVersions.Length != 4)
            throw new Exception( "Invalid version string (" + lsVersion + ")." );

         int liIncBuild = Convert.ToInt32( lasVersions[3] ) + 1;

         return lasVersions[0] + "." + lasVersions[1] + "." +
            lasVersions[2] + "." + liIncBuild;
      }
      
      static void Main( string[] args )
      {
         if( args == null || args.Length != 1 )
         {
            Console.WriteLine( "Usage: IncrementBuildNr <AssemblyInfo.cs file>" );
            Environment.Exit( 1 );
         }

         FileInfo loFile = new FileInfo( args[0] );

         if(loFile.Exists == false)
         {
            Console.WriteLine( "ERROR: file (" + args[0] + ") does not exist" );
            Environment.Exit( 2 ); 
         }

         if("AssemblyInfo.cs".Equals( loFile.Name ) == false )
         {
            Console.WriteLine( "ERROR: must pass an AssemblyInfo.cs file" );
            Environment.Exit( 2 );
         }

         FileInfo loOutFile = new FileInfo( args[0] + ".tmp" );

         StreamReader loReader = null;
         StreamWriter loWriter = null;

         try
         {
            loReader = new StreamReader( loFile.OpenRead() );
            loWriter = new StreamWriter( loOutFile.OpenWrite(), loReader.CurrentEncoding );

            String lsLine = loReader.ReadLine();
            while(lsLine != null)
            {
               if( lsLine.StartsWith( "[assembly: AssemblyVersion" ) )
               {
                  String lsVersion = incrementVersion( lsLine );
                  lsLine = "[assembly: AssemblyVersion( \"" + lsVersion + "\" )]";
               }
               else if( lsLine.StartsWith( "[assembly: AssemblyFileVersion" ) )
               {
                  String lsVersion = incrementVersion( lsLine );
                  lsLine = "[assembly: AssemblyFileVersion( \"" + lsVersion + "\" )]";
               }
               loWriter.WriteLine( lsLine );
               lsLine = loReader.ReadLine();
            }
            loReader.Close();
            loWriter.Close();

            loFile.Delete();
            loOutFile.MoveTo( loFile.FullName );
         }
         catch( Exception e )
         {
            Console.WriteLine( "ERROR: " + e.Message );
            Environment.Exit( 1 );
         }
         finally
         {
            try{ if(loReader != null ) loReader.Close(); }
               catch{ /* ignore */ }
            try{ if( loWriter != null ) loWriter.Close(); }
               catch{ /* ignore */ }
         }
         Environment.Exit( 0 );
      } // end main
   }
}
